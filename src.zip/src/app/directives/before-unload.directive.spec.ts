import { BeforeUnloadDirective } from './before-unload.directive';

describe('BeforeUnloadDirective', () => {
  it('should create an instance', () => {
    const directive = new BeforeUnloadDirective();
    expect(directive).toBeTruthy();
  });
});
